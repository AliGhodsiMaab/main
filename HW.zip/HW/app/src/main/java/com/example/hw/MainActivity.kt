package com.example.hw

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
package com.example.internetlogger;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
package com.example.internetlogger;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.WorkRequest;
import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WorkRequest statusWorkRequest = new PeriodicWorkRequest.Builder(StatusWorker.class, 2, TimeUnit.MINUTES)
            .build();

        WorkManager.getInstance(this).enqueue(statusWorkRequest);

        Button showLogsButton = findViewById(R.id.show_logs_button);
        showLogsButton.setOnClickListener(v -> {
        Intent intent = new Intent(MainActivity.this, LogActivity.class);
        startActivity(intent);
    });
    }
}
