// StatusWorker.java
package com.example.internetlogger;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class StatusWorker extends Worker {
    public StatusWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        boolean isBluetoothEnabled = BluetoothAdapter.getDefaultAdapter().isEnabled();
        boolean isAirplaneModeOn = Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1
                ? Settings.System.getInt(context.getContentResolver(), Settings.System.AIRPLANE_MODE_ON, 0) != 0
                : Settings.Global.getInt(context.getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) != 0;

        String logEntry = new Date() + ": Bluetooth is " + (isBluetoothEnabled ? "enabled" : "disabled") + ", Airplane mode is " + (isAirplaneModeOn ? "on" : "off");

        try (FileWriter writer = new FileWriter(context.getFilesDir() + "/log.json", true)) {
            writer.write(logEntry + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }

        Log.i("worker_airplane", logEntry);

        return Result.success();
    }
}
