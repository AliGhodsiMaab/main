// LogActivity.java
package com.example.internetlogger;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LogActivity extends AppCompatActivity {
    private TextView logTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        logTextView = findViewById(R.id.log_text_view);
        List<String> logs = readLogs();

        StringBuilder logContent = new StringBuilder();
        for (String log : logs) {
            logContent.append(log).append("\n");
        }

        logTextView.setText(logContent.toString());
    }

    private List<String> readLogs() {
        List<String> logs = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(getFilesDir() + "/log.json"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                logs.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Collections.reverse(logs);  // نمایش لاگ‌ها به صورت نزولی
        return logs;
    }
}
